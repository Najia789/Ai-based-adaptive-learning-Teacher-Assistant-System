"""
Test suite for Student Tracking System.
All test files are located in this directory.
"""

